<?php

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
	<link rel="stylesheet" href="style.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.js"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.min.js"/>

    <title>Hospital|Hospital Management System|</title>
  </head>
  <body>
 
   <ul class="nav nav-pills fixed-top" >
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="index.php"><i class="fa fa-dashboard"></i>Home</a>
  </li>

 <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><i class="fa fa-edit"></i>Services</a>
    <ul class="dropdown-menu bg-primary">

      <li><a class="dropdown-item" href="Doctorres.php">Doctor Registration</a></li>
      <li><a class="dropdown-item" href="appointment.php">Appointment</a></li>
      
    </ul>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="aboutus.php"><i class="fa fa-address-card"></i>About us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i>Contect us</a>
  </li>
    <li class="nav-item">
    <a class="nav-link" href="#"><i class="fa fa-bell"></i>Notification</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="login.php"><i class="fa fa-sign-in"></i>Login</a>
  </li>
</ul>
<!-- slider---->
<div class="container col-5 border border-danger rounded mt-5">

<h1 class="text-light border-bottom text-center mt-5 mb-4" style="background:linear-gradient(maroon,cyan)">Appointment</h1>


<form class="form-group" action="code/apoitinsert.php" autocomplete="off" method="post">
<!--<div class="mb-2">
<label class="form-label text-primary" required>Serial No.:<span class="text-danger">*</span></label>
<input type="number" class="form-control"/>
</div>-->
<div class="mb-2">
<label class="form-label text-primary">PID:</label>
<input type="text" name="pid" disabled value="" class="form-control"/>
</div>

<!--<div class="mb-2">
<label class="form-label text-primary" required>Time:<span class="text-danger">*</span></label>
<input type="time" class="form-control"/>
</div>-->
<!--<div class="mb-2">
<label class="form-label text-primary">Status:</label>
<input type="text" name="status" class="form-control"/>
</div>-->

<div class="mb-2">
<label class="form-label text-primary" required>Name:<span class="text-danger">*</span></label>
<input type="text" name="name" value="" class="form-control"/>
</div>




<div class="mb-2">
<label class="form-label text-primary">Address:</label>
<textarea value="" name="address" class="form-control"></textarea>
</div>




<div class="mb-2">
<label class="form-label text-primary">Guardian Name:</label>
<input type="text" name="gname" class="form-control"/>
</div>



<div class="mb-2">
<label class="form-label text-primary"required>Apointment Date:<span class="text-danger">*</span></label>
<input type="date" name="apodate" class="form-control text-primary"/>
</div>


<!--<div class="mb-2">
<label class="form-label text-primary">Update:</label>
<input type="text" class="form-control"/>
</div>-->
<div class="mb-2">
<label class="form-label text-primary" required>Problem:<span class="text-danger">*</span></label>
<!--<input type="text" name="problem" value="" class="form-control"/>-->

<textarea value="" name="problem" class="form-control"></textarea>
</div>

</div>




<div class="mb-4 d-grid gap-2" style="width:">

<center><input type="Submit" class="btn btn-success" name="submit"  value="Submit"/></center>
</div>



</form>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	</div>
  </body>
</html>