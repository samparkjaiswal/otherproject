<?php

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
	<link rel="stylesheet" href="style.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.js"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.min.js"/>

    <title>Hospital|Hospital Management System|</title>
  </head>
  <body>
  
   <ul class="nav nav-pills fixed-top" >
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="index.php"><i class="fa fa-dashboard"></i>Home</a>
  </li>

 <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><i class="fa fa-edit"></i>Services</a>
    <ul class="dropdown-menu bg-primary">
   <!--   <li><a class="dropdown-item" href="patientres.html">Patient Registration</a></li>-->
      <li><a class="dropdown-item" href="Doctorres.php">Doctor Registration</a></li>
      <li><a class="dropdown-item" href="appointment.php">Appointment</a></li>
      
    </ul>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="aboutus.php"><i class="fa fa-address-card"></i>About us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i>Contect us</a>
  </li>
    <li class="nav-item">
    <a class="nav-link" href="#"><i class="fa fa-bell"></i>Notification</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="login.php"><i class="fa fa-sign-in"></i>Login</a>
  </li>
</ul>
<!-- End Navbar---->
<div class="container-fluid mt-5">
<div class="row bg-dark">
<div class="col-sm-12">
<h1 class="text-white text-center m-5"><span style="font-size:12px;">KMC Digital Hospital>>About Us</span></br>About Us</h1>
</div>
</div>

<div class="row bg-light pt-5">
<div class="col-sm-12">
<h1 class="text-center text-danger pb-5" style="font-weight:1000">About KMC Digital Hospital</h1>
<p> <b>KMC DIGITAL HOSPITAL</b> – The premiere multi-specialty and super specialty care hospital of eastern UP, It is one of best centers of medical excellence. The hospital has been built with the vision for strong foundation of the state-of-the-art facilities, best medical expertise, research, education and charitable endeavors; that it serves patients from all walks of life – national and international. Based on a powerful Sanskrit inspiration, <b>“Sarvetra Sukhina:Santu, Sarve SantuNiramaya:”</b> which means “Let all be blissful, Let all stay healthy“, the hospital has focused its operation on providing quality care with a human touch; which truly reflects the essence of its motto “feather touch human care“.

<b>KMC DIGITAL HOSPITAL </b>the premier multi-specialty and super specialty digital care hospital of eastern UP, located in the heart of Maharajganj;, It has over 300 beds with one of the largest Intensive Care Units (ICUs), most advanced a Operation Theaters, more than 100 Consultants from across the globe, providing care across 40 specialties.

</p>
</div>
</div>



<div class="row aligh-items-center py-3 bg-primary">
            <div class="col-md-6  text-light">
                <div class="copy">
                    Copyright <script>document.write(new Date().getFullYear());</script>2022 © MMITIEN All Rights Reserved. 
                </div>
            </div>
            <div class="col-md-6  text-light text-right">
                <div class="d-flex justify-content-end">
                    <a href="https://www.facebook.com/saratechnologies/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/saratechnology" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-twitter"></i></a>
                    <a href="https://in.linkedin.com/company/sara-technologies-pvt-ltd" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-linkedin"></i></a>
                    <a href="https://www.instagram.com/websarasolutions/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-instagram"></i></a>
                    <a href="https://in.pinterest.com/saratechnologiespvtltd/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-pinterest"></i></a>
                    <a href="https://www.youtube.com/channel/UCl748soyEhy9DLpib3nWE8w" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>



    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	</div>
  </body>
</html>