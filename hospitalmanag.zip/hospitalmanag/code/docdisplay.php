<html>

<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

<table border="2" cellspacing="5" style="text-align:center">


<tr>

<th>Id</th>
<th>Name</th>
<th>Father Name</th>
<th>Mobile Number</th>
<th>Spacialist</th>
<th>Qualification</th>
<th>Date</th>
<th colspan="2">Operation</th>

</tr>














<?php

include "hosconn.php";

$query="select * from doctor";

$data=mysqli_query($conn,$query);

//$row=mysqli_num_rows($data);

//echo $row;

//$res=mysqli_fetch_assoc($data);

//echo $res;

if($data)
	
	{
		//echo "Table Record Found";
		
		while($res=mysqli_fetch_assoc($data))
		{
			echo "
			<tr>
				<td>".$res['id']."</td>
				<td>".$res['name']."</td>
				<td>".$res['fname']."</td>
				<td>".$res['mobile']."</td>
				<td>".$res['spacialist']."</td>
				<td>".$res['qualification']."</td>
				<td>".$res['dt']."</td>
				
				<td><a href='docupdate.php?uid=$res[id]'><span class='fa fa-edit' style='color:blue'></span></a></td>
				
				<td><a href='docdel.php?uid=$res[id]' onclick='return deleteuser()'><span class='fa fa-trash' style='color:red'></span></a></td>
			</tr>
			
			";
		}
	}
else
{
	echo "No Record Found";
}
?>

<script>

function deleteuser()
{
	var cbox=confirm('Are You Sure Want To Delete This Record');
	if(cbox==true)
	{
		return true;
	}
	else{
		return false;
	}
	
}

</script>


</table>


</body>

</html>
