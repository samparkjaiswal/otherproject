<?php

include "hosconn.php";

$id=$_POST['id'];
$name=$_POST['name'];
$fname=$_POST['fname'];
$mobile=$_POST['mobile'];
$spacialist=$_POST['spacialist'];
$qualification=$_POST['qualification'];
$dt=date('d/m/Y');




$query="insert into doctor values('$id','$name','$fname','$mobile','$spacialist','$qualification','$dt')";

$data=mysqli_query($conn,$query);

if($data)
{
	echo "<script>alert('Data Inserted');window.location.href='../Doctorres.php'</script>";
}
else
{
	echo "<script>alert('Data Not Inserted');window.location.href='../Doctorres.php'</script>";
}

?>