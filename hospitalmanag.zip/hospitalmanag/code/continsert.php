<?php

include "hosconn.php";

$cid=$_POST['cid'];
$query=$_POST['query'];
$name=$_POST['name'];
$pname=$_POST['pname'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$complain=$_POST['complain'];
$date=date('Y/m/d');

$query="insert into contact values('$cid','$query','$name','$pname','$contact','$email','$complain','$date')";

$data=mysqli_query($conn,$query);

if($data)
{
	echo "<script>alert('Thanks For Contact');window.location.href='../contactus.php'</script>";
}
else
{
	echo "<script>alert('Insertion Problem');window.location.href='../contactus.php'</script>";
}

?>