<?php

include "hosconn.php";

$cid=$_GET['id'];

$query="delete from contact where cid='$cid'";

$data=mysqli_query($conn,$query);

if($data)
{
	//echo "<script>alert('Delete Record');window.location.href='contdisplay.php'</script>";
	header('location:../hosadmin/Contact Management.php');
}
else
{
	echo "<script>alert('Delete Not Record');window.location.href='../hosadmin/Contact Management.php'</script>";
}


?>