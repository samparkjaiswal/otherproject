<?php

include "hosconn.php";

$pid=$_POST['pid'];
$name=$_POST['name'];
$address=$_POST['address'];
$gname=$_POST['gname'];
$apodate=$_POST['apodate'];
$problem=$_POST['problem'];
$date=date('Y/m/d');


$query="insert into apointment value('$pid','$name','$address','$gname','$apodate','$problem','$date')";

$data=mysqli_query($conn,$query);

if($data)
{
	echo "<script>alert('Data Inserted');window.location.href='../appointment.php'</script>";
}
else
{
	echo "<script>alert('Data Insertion Failed');window.location.href='../appointment.php'</script>";
}

?>