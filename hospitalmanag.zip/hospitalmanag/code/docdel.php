<?php

include "hosconn.php";

$id=$_GET['uid'];

$query="delete from doctor where id='$id'";

$data=mysqli_query($conn,$query);

if($data)
{
	//echo "<script>alert('Data Deleted');window.location.href='docdisplay.php'</script>";
	header('location:../hosadmin/Doctor Management.php');
}
else
{
	echo "<script>alert('Data Not Deleted');window.location.href='../hosadmin/Doctor Management.php'</script>";
}


?>