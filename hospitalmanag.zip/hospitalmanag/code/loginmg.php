<?php

session_start();

include "hosconn.php";

$user=$_POST['user'];
$pass=$_POST['pass'];


$query="select * from login where user='$user' and pass='$pass'";

$data=mysqli_query($conn,$query);

$row=mysqli_num_rows($data);

if($row>0)
{
	$SESSION['username']=$user;
	echo "<script>alert('Welcome to Admin Zone');window.location.href='../hosadmin/Admin.php'</script>";
}
else
{
	echo "<script>alert('Wrong Username or Password');window.location.href='../login.php'</script>";
}



?>