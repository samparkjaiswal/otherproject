<?php

include "hosconn.php";
//error_reporting(0);

$upid=$_GET['uid'];

$query="select * from doctor where id=$upid";

$data=mysqli_query($conn,$query);

//$row=mysqli_num_rows($data);
//$res=mysqli_fetch_assoc($data);

while($res=mysqli_fetch_assoc($data))
{
	$id=$res['id'];
	$name=$res['name'];
	$fname=$res['fname'];
	$mobile=$res['mobile'];
	$spacialist=$res['spacialist'];
	$qualification=$res['qualification'];
}

?>

<?php

if(isset($_POST['update']))
{
	//$id=$_POST['id'];
	$name=$_POST['name'];
	$fname=$_POST['fname'];
	$mobile=$_POST['mobile'];
	$spacialist=$_POST['spacialist'];
	$qualification=$_POST['qualification'];
	$dt=date('d/m/Y');
	$update="update doctor set name='$name',fname='$fname',mobile='$mobile',spacialist='$spacialist',qualification='$qualification',dt='$dt' where id='$upid'";
	
	$result=mysqli_query($conn,$update);
	
	if($result)
	{
		echo "<script>alert('Record Updated');window.location.href='../hosadmin/Doctor Management.php'</script>";
	}
	else
	{
		echo "<script>alert('Record Not Updated');window.location.href='../hosadmin/Doctor Management.php'</script>";
	}
}

?>





<?php

?>

<html>
  <head>
    <!-- Required meta tags -->
 <!--   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">-->

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
	<link rel="stylesheet" href="style.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.js"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.min.js"/>

    <title>Hospital|Hospital Management System|</title>
  </head>
  <body>
  
<!--  <ul class="nav nav-pills fixed-top" >
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="index.php"><i class="fa fa-dashboard"></i>Home</a>
  </li>

 <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><i class="fa fa-edit"></i>Services</a>
    <ul class="dropdown-menu bg-primary">
    
      <li><a class="dropdown-item" href="Doctorres.php">Doctor Registration</a></li>
      <li><a class="dropdown-item" href="appointment.php">Appointment</a></li>
      
    </ul>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="aboutus.php"><i class="fa fa-address-card"></i>About us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i>Contect us</a>
  </li>
    <li class="nav-item">
    <a class="nav-link" href="#"><i class="fa fa-bell"></i>Notification</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#"><i class="fa fa-sign-in"></i>Login</a>
  </li>
</ul-->
<!-- slider---->
<div class="container col-6 border border-danger rounded mt-5">

<h1 class="text-primary border-bottom text-center mt-5 mb-4">Doctor Registration</h1>


<form class="form-group" action=""  method="post" autocomplete="off">


<div class="mb-4">
<!--<label class="form-label text-primary" type="">Id:</label>-->
<input type="hidden" name="id" value="<?php echo "$id" ?>" disabled class="form-control"/>
</div>


<div class="mb-4">
<label class="form-label text-primary">Name:</label>
<input type="text" name="name" value="<?php echo "$name" ?>" class="form-control"/>
</div>
<div class="mb-4">
<label class="form-label text-primary">Father Name:</label>
<input type="text" name="fname" value="<?php echo "$fname" ?>" class="form-control"/>
</div>
<div class="mb-4">
<label class="form-label text-primary">Mobile No.:</label>
<input type="text" name="mobile" value="<?php echo "$mobile"  ?>" class="form-control"/>
</div>
<div class="mb-4">
<label class="form-label text-primary">Spacialist:</label>
<input type="text" name="spacialist" value="<?php echo "$spacialist" ?>" class="form-control"/>
</div>

<!--<div class="mb-4">
<label class="form-label text-primary">Photo:</label>
<input type="file" class="form-control"/>
</div>-->

<div class="mb-4">
<label class="form-label text-primary">Qualification:</label>

<select class="text-primary" name="qualification">
<option>Select</option>
<option value="MBBS"

<?php

if($qualification=="MBBS")
{
	echo "selected";
}



?>

>MBBS</option>
<option value="B.Med"

<?php

if($qualification=="B.Med")
{
	echo "selected";
}


?>

>B.Med</option>
<option value="B.Surg"

<?php

if($qualification=="B.Surg")
{
	echo "selected";
}




?>

>B.Surg</option>
<option value="MD"
<?php
if($qualification=="MD")
{
	echo "selected";
}

?>

>MD</option>
</select>
</div>


<div class="mb-4 d-grid gap-2">

<input type="Submit" class="btn btn-success" name="update" value="Update"/>
</div>



</form>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	</div>
  </body>
</html>