<?php

include "hosconn.php";

$cid=$_GET['uid'];

$query="select * from contact where cid='$cid'";

$data=mysqli_query($conn,$query);

//$res=mysqli_fetch_assoc($data);

while($res=mysqli_fetch_assoc($data))
{
	$cid=$res['cid'];
	$query=$res['query'];
	$name=$res['name'];
	$pname=$res['pname'];
	$contact=$res['contact'];
	$email=$res['email'];
	$complain=$res['complain'];
}

?>


<?php

if(isset($_POST['update']))
{
	//$cid=$_POST['cid'];
	$query=$_POST['query'];
	$name=$_POST['name'];
	$pname=$_POST['pname'];
	$contact=$_POST['contact'];
	$email=$_POST['email'];
	$complain=$_POST['complain'];
	$date=date('Y/m/d');
	
	$update="update contact set query='$query',name='$name',pname='$pname',contact='$contact',email='$email',complain='$complain',date='$date' where cid='$cid' ";
	
	$result=mysqli_query($conn,$update);
	if($update)
	{
		echo "<script>alert('Record Updated');window.location.href='../hosadmin/Contact Management.php'</script>";
	}
	else
	{
		echo "<script>alert('Record Not Updated');window.location.href='../hosadmin/Contact Management.php'</script>";
	}
}


?>






<?php

?>

<html>
  <head>
    <!-- Required meta tags -->
 <!--   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">-->

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
	<link rel="stylesheet" href="style.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.js"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.min.js"/>

    <title>Hospital|Hospital Management System|</title>
  </head>
  <body>
  
   <ul class="nav nav-pills fixed-top" >
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="index.php"><i class="fa fa-dashboard"></i>Home</a>
  </li>

 <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><i class="fa fa-edit"></i>Services</a>
    <ul class="dropdown-menu bg-primary">
 
      <li><a class="dropdown-item" href="Doctorres.php">Doctor Registration</a></li>
      <li><a class="dropdown-item" href="appointment.php">Appointment</a></li>
      
    </ul>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="aboutus.php"><i class="fa fa-address-card"></i>About us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i>Contect us</a>
  </li>
    <li class="nav-item">
    <a class="nav-link" href="#"><i class="fa fa-bell"></i>Notification</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#"><i class="fa fa-sign-in"></i>Login</a>
  </li>
</ul>
<!-- End Navbar---->
<div class="container-fluid mt-5">
<div class="row bg-dark">
<div class="col-sm-12">
<h1 class="text-white text-center m-5"><span style="font-size:12px;">KMC Digital Hospital>>Contact Us</span></br>Contact Us</h1>
</div>
</div>

<div class="row bg-light pt-5">

<h1 class="text-center text-danger pb-2" style="font-weight:1000">Our Contact INFO</h1>
<div class="col-sm-4">
<h1 class="text-center" style="font-size:80px;background:orange;border-radius:50%;"><span class="fa fa-map-marker-alt  rounded-circle"></span></h1>
<h4 class="text-center">VISIT KMC DIGITAL HOSPITAL</h4>
<p class="text-center">KMC Digital Hospital,<br>
Mahuawa, Farenda Road,<br>
Maharajganj (U.P.)-273303</p>
</div>
<div class="col-sm-4">
<h1 class="text-center" style="font-size:80px;background:orange;border-radius:50%;"><span class="fa fa-envelope  rounded-circle"></span></h1>
<h4 class="text-center">OUR EMAIL</h4>
<p class="text-center">lifeloverhacker@gmail.com,<br>mmitian@gmail.com</p>
</div>
<div class="col-sm-4">
<h1 class="text-center" style="font-size:80px;background:orange;border-radius:50%;"><i class="fa fa-phone rounded-circle"></i></h1>
<h4 class="text-center">CALL US</h4>
<p class="text-center">(+91) 07754901214<br>
(+91) 07754901213<br>
Toll Free: 1800-10-28-007</p>
</div>
</div>

<div class="row bg-white">
<h1 class="text-center text-primary border-bottom">Our Location</h1>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227825.4781133533!2d80.94616521677925!3d26.847168379271583!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39995761144d1493%3A0x9901bb1bd11fdb24!2sKMC%20Hospital!5e0!3m2!1sen!2sin!4v1641156401655!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

</div>


<div class="row bg-white pt-5">
 
             <h1 class="text-center mb-5"><span style="font-size:15px">Feel Free To Contact Us</span><br>
GET IN TOUCH</h1>
 
		<div class="col-sm-1"></div>
		<div class="col-sm-6 border border-danger">
		
		<form action=""  method="post" autocomplete="off">
		
		<h3>Personal Details</h3>
		
		
		<div class="mb-2">
		<label class="form-label text-primary">Complain Id</label>
		<input type="text" class="form-control" value="<?php echo "$cid" ?>" name="cid" disabled>
		</div>
		
		
		<div class="mb-2">
		<label class="form-label text-primary">Type of query*(required)</label>
		<select class="form-control" name="query">
		<option hidden>--Select Type Of Query--</option>
		<option value="Enquiry"
		 <?php
		 
		 if($query=="Enquiry")
		 {
			 echo "selected";
		 }
		 
		 ?>
		 
		
		
		>Enquiry</option>
		<option value="DoctorOpinion"
		
		<?php
		
		if($query=="DoctorOpinion")
		{
			echo "selected";
		}
		
		?>
		
		
		>DoctorOpinion</option>
		
		<option value="Appointment"
		
		<?php
		
		if($query=="Appointment")
		{
			echo "selected";
		}
		
		
		?>
		
		
		
		>Appointment</option>
		<option value="Complain"

		<?php
		
		if($query=="Complain")
		{
			echo "selected";
		}
		
		
		?>
		
		>Complain</option>
		<option value="Other"
			
		<?php
		
		if($query=="Other")
		{
			echo "selected";
		}
		
		
		?>
		
		>Other</option>
		</select>
		</div>
		<div class="mb-2">
		<label class="form-label text-primary">Name*(required)</label>
		<input type="text" class="form-control" value="<?php echo "$name" ?>" name="name" required>
		</div>
		<div class="mb-2">
		<label class="form-label text-primary">Name of Patient*</label>
		<input type="text" class="form-control" value="<?php echo "$pname" ?>" name="pname" required>
		</div>
		<div class="mb-2">
		<label class="form-label text-primary">Contact No.*</label>
		<input type="text" class="form-control" value="<?php echo "$contact" ?>" name="contact" required>
		</div>
		<div class="mb-2">
		<label class="form-label text-primary">Email*</label>
		<input type="email" name="email" value="<?php echo "$email" ?>" class="form-control" required>
		</div>
		<div class="mb-2">
		<label class="form-label text-primary">Complain/Feedback/Other Massage</label>
		<textarea class="form-control"type="text" name="complain" ><?php echo "$complain" ?></textarea>
		</div>
		<div class="mb-2 d-grid gap-2">
		
		<input type="Submit" value="Update" class="btn btn-success" name="update">
		</div>
		</form>
		</div>
		<div class="col-sm-4">
		<p ><i class="fa fa-phone text-danger"></i>(+91) 07754901214, (+91) 07754901213<br>
<i class="fa fa-envelope text-danger"></i>info@kmchospitals.com<br>
<i class="fa fa-globe text-danger"></i>http://www.kmchospitals.com<br>
<i class="fa fa-map-marker-alt text-danger"></i>KMC Digital Hospital,
Mahuawa, Farenda Road,
Maharajganj (U.P.)-273303<br>

<i class="fa fa-clock text-danger "></i>Man to Sun- 8:00 am to 8:00 pm</p>
		
		</div>
		<div class="col-sm-1"></div>
		
		
		</div>


<div class="row aligh-items-center py-3 bg-primary">
            <div class="col-md-6  text-light">
                <div class="copy">
                    Copyright <script>document.write(new Date().getFullYear());</script>2022 © MMITIEN All Rights Reserved. 
                </div>
            </div>
            <div class="col-md-6  text-light text-right">
                <div class="d-flex justify-content-end">
                    <a href="https://www.facebook.com/saratechnologies/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/saratechnology" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-twitter"></i></a>
                    <a href="https://in.linkedin.com/company/sara-technologies-pvt-ltd" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-linkedin"></i></a>
                    <a href="https://www.instagram.com/websarasolutions/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-instagram"></i></a>
                    <a href="https://in.pinterest.com/saratechnologiespvtltd/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-pinterest"></i></a>
                    <a href="https://www.youtube.com/channel/UCl748soyEhy9DLpib3nWE8w" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>
		
		



    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	</div>
  </body>
</html>













