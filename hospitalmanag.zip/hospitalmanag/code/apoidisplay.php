
<html>

<head>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 

</head>

<body>

<table border="2" style="text-align:center" cellspacing="5">

<th>PID</th>
<th>NAME</th>
<th>ADDRESS</th>
<th>GUARDIAN NAME</th>
<th>APOINTMENT DATE</th>
<th>PROBLEM</th>
<th>DATE</th>
<th colspan="2">OPERATION</th>









<?php

include "hosconn.php";

$query="select * from apointment";

$data=mysqli_query($conn,$query);

//$res=mysqli_fetch_assoc($data);
if($data)
{
	//echo "Table Have Record";
	while($res=mysqli_fetch_assoc($data))
	{
		echo "
		<tr>
			<td>".$res['pid']."</td>
			<td>".$res['name']."</td>
			<td>".$res['address']."</td>
			<td>".$res['gname']."</td>
			<td>".$res['apodate']."</td>
			<td>".$res['problem']."</td>
			<td>".$res['date']."</td>
			
			<td><a href='apoupdate.php?id=$res[pid]' ><span class='fa fa-edit' style='color:blue'></span></a></td>
			
			<td><a href='apodel.php?id=$res[pid]' onclick='return deleteuser()'><span class='fa fa-trash' style='color:red'></span></a></td>
		</tr>
		
		
		";
	}
}
else
{
	echo "Table Have No Record";
}



?>

<script>

function deleteuser()
{
	var cbox=confirm('Are You Sure To Want Delete This Record');
	if(cbox==true)
	{
		return true;
	}
	else
	{
		return false; 
	}	
}


</script>

</table>

</body>

</html>