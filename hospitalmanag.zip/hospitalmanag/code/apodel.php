<?php

include "hosconn.php";

$pid=$_GET['id'];

$query="delete from apointment where pid='$pid'";

$data=mysqli_query($conn,$query);

if($data)
{
	//echo "<script>alert('Data Deleted');window.location.href='apoidisplay.php'</script>";
	header('location:../hosadmin/Patient Management.php');
}
else
{
	echo "<script>alert('Data Deleted');window.location.href='../hosadmin/Patient Management.php'</script>";
}


?>