<html>

<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
</head>

<body>

<table border="2" cellspacing="5" style="text-align:center">

<tr>
<th>Complain Id</th>
<th>Query</th>
<th>Name</th>
<th>Patient Name</th>
<th>Contact</th>
<th>Email</th>
<th>Complain</th>
<th>Date</th>
<th colspan="2">Operation</th>

</tr>











<?php

include "hosconn.php";

$query="select * from contact";

$data=mysqli_query($conn,$query);
//$res=mysqli_fetch_assoc($data);
if($data)
{
	//echo "Table Have Record";
	while($res=mysqli_fetch_assoc($data))
	{
		echo "
		<tr>
			<td>".$res['cid']."</td>
			<td>".$res['query']."</td>
			<td>".$res['name']."</td>
			<td>".$res['pname']."</td>
			<td>".$res['contact']."</td>
			<td>".$res['email']."</td>
			<td>".$res['complain']."</td>
			<td>".$res['date']."</td>
			
			<td><a href='contupdate.php?uid=$res[cid]'><span class='fa fa-edit' style='color:blue'></span></a></td>
			
			<td><a href='condel.php?id=$res[cid]' onclick='return deleteuser()'><span class='fa fa-trash' style='color:red'></span></a></td>
		
		</tr>
		
		";
	}
}
else
{
	echo "Table Have No Record";
}


?>


<script>

function deleteuser()
{
	var cbox=confirm('Are You Sure To Want Delete This Record');
	if(cbox==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}

</script>


</table>

</body>


</html>
