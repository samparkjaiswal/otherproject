<?php 

$conn=mysqli_connect("localhost","root","","hospital");

if($conn)
{
	//echo "Connection Is Succesfull";
}
else
{
	echo "Connection Problem";
	mysqli_error($conn);
}


?>