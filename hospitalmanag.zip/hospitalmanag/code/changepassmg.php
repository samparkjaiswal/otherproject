<?php

include "hosconn.php";


$opass=$_POST['opass'];
$npass=$_POST['npass'];

$query="select pass from login where pass='$opass'";

$data=mysqli_query($conn,$query);

$row=mysqli_fetch_array($data);
if($row>0)
{
	$update="update login set pass='$npass'";
	mysqli_query($conn,$update);
	
	echo "<script>alert('Password Change Successfully');window.location.href='../hosadmin/Change Password.php'</script>";
}
else
{
	echo "<script>alert('Old Password Is Wrong');window.location.href='../hosadmin/Change Password.php'</script>";
}

?>