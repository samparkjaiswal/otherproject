<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
	<link rel="stylesheet" href="style.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.js"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/11.0.2/bootstrap-slider.min.js"/>

    <title>Hospital|Hospital Management System|</title>
  </head>
  <body>
  
   <ul class="nav nav-pills">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#"><i class="fa fa-dashboard"></i>Home</a>
  </li>

 <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><i class="fa fa-edit"></i>Services</a>
    <ul class="dropdown-menu bg-primary">
     <!-- <li><a class="dropdown-item" href="Patientres.html">Patient Registration</a></li>-->
      <li><a class="dropdown-item" href="Doctorres.php">Doctor Registration</a></li>
      <li><a class="dropdown-item" href="appointment.php">Appointment</a></li>
      
    </ul>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="aboutus.php"><i class="fa fa-address-card"></i>About us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i>Contect us</a>
  </li>
    <li class="nav-item">
    <a class="nav-link" href="#"><i class="fa fa-bell"></i>Notification</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="login.php"><i class="fa fa-sign-in"></i>Login</a>
  </li>
</ul>
<!-- slider---->
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/sliderphoto/5.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/sliderphoto/4.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/sliderphoto/6.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<div class="container-fluid">
<!---start row--->
<div class="row" style="background:#fff;opacity:0.9;">
<h1 class="text-center text-primary">Our Doctors</h1>
<div class="col-sm-4 mt-2 border border-secondary">
<center>
<img src="img/1.jpg"/ height="150px" width="200px" class="border border-danger rounded mt-2" >
<h2 class="text-dark">Dr. Chadda</h2>
<h4>Colon and Rectal Surgeons</h4>
<p>You would see these doctors for problems with your small intestine, colon, and bottom. They can treat colon cancer, hemorrhoids, and inflammatory bowel disease. </p>
</center>
</div>
<div class="col-sm-4 mt-2 border border-secondary">
<center>
<img src="img/2.jpg" height="150px" width="200px" class="border border-danger rounded mt-2" >
<h2 class="text-dark">DR.Ramesh</h2>
<h4>Emergency Medicine Specialists</h4>
<p>These doctors make life-or-death decisions for sick and injured people, usually in an emergency room. Their job is to save lives and to avoid or lower the chances of disability.</p>
</center>
</div>
<div class="col-sm-4 mt-2 border border-secondary">
<center>
<img src="img/3.jpg"/ height="150px" width="200px" class="border border-danger rounded mt-2" >
<h2 class="text-Dark"> Dr.Anjlina</h2>
<h4>Neurologists</h4>
<p>These are specialists in the nervous system, which includes the brain, spinal cord, and nerves. They treat strokes, brain and spinal tumors, epilepsy, Parkinson's disease, and Alzheimer's disease.</p>
</center>
</div>
</div>
<!---end--->

<!-----------------ddddddddddddddddd----------------------->
<div class="row">
<section class="section bg-theme features" id="" >
    <div class="container">
        <div class="row" >
            <div class="col-md-12 text-center" >
                <h3 class="heading text-white">HMS Module Includes Following Management System</h3>
                <p>
                    With cutting-edge modern technologies and innovation, the best healthcare management software has been developed as per the suggestions of Doctors &amp; Healthcare Experts for easy use to get timely notification alert. This generates automated billing &amp; reports in a few clicks only.
                </p> <br>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <ul class="list-unstyled row">
                            <li class="col-md-3 my-3">
                                <img src="img/managment/1.png" alt="patient" width="50" class="img-fluid">
                                <p>Patient Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/2.png" alt="doctor" width="50" class="img-fluid">
                                <p>Doctor Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/3.png" alt="opd" width="50" class="img-fluid">
                                <p>OPD Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/4.png" alt="ipd" width="50" class="img-fluid">
                                <p>IPD Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/5.png" alt="ot" width="50" class="img-fluid">
                                <p>OT Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/6.png" alt="pathology" width="50" class="img-fluid">
                                <p>Pathology/Radiology Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/7.png" alt="Pharmacy" width="50" class="img-fluid">
                                <p>Pharmacy Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/8.png" alt="Inventory" width="50" class="img-fluid">
                                <p>Inventory Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/9.png" alt="Dental" width="50" class="img-fluid">
                                <p>Dental Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/10.png" alt="Gynecology" width="50" class="img-fluid">
                                <p>Gynecology Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/11.png" alt="Paediatric " width="50" class="img-fluid">
                                <p>Paediatric  Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/12.png" alt="Eye " width="50" class="img-fluid">
                                <p>Ophthalmology Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/13.png" alt="Blood Bank " width="50" class="img-fluid">
                                <p>Blood Bank  Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/14.png" alt="HR Payroll" width="50" class="img-fluid">
                                <p>HR Payroll</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/15.png" alt="Ambulance" width="50" class="img-fluid">
                                <p>Ambulance Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/16.png" alt="Queue" width="50" class="img-fluid">
                                <p>Queue Management</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/17.png" alt="TPA Services" width="50" class="img-fluid">
                                <p>TPA Services</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/18.png" alt="Machine Interface" width="50" class="img-fluid">
                                <p>Machine Interface</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/19.png" alt="MIS Report" width="50" class="img-fluid">
                                <p>MIS Report</p>
                            </li>
                            <li class="col-md-3 my-3">
                                <img src="img/managment/20.png" alt="Patient Mobile App" width="50" class="img-fluid">
                                <p>Patient Mobile App </p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</div>




<div class="row" style="background:#fff;opacity:0.9;">
<div class="col-sm-6">
<h1 class="text-center text-primary">About US</h1>
<h3 class="text-primary">What We Do</h3>
<p>In addition to offering traditional and established medical care services, Strong is distinguished with its tertiary and quaternary services. This means Strong has the personnel and facilities to provide advanced medical inquiry and treatments that are not widely accessible in this region.

</p>
<h3 class="text-primary">How We Do It</h3>
<p>Strong is an exemplary teaching hospital with advanced scientific proficiencies, robust patient care services, and formidable community relations. These qualities and the dedicated staff who support them are precisely what elevate Strong’s reputation. As a teaching hospital, all of Strong’s medical clinicians are clinician scholars with faculty appointments (at the University of Rochester School of Medicine and Dentistry) who supervise residents and participate in the education of residents and students. The result is a learning environment immersed in research, education, community, and innovati0</p>
</div>
<div class="col-sm-6">
<img class="img" src="img/4.jpg" width="100%"/>
</div>
</div>
</div>

<div class="container-fluid">
<div class="row" style="background:#fff;opacity:0.9;">
<h1 class="text-center text-primary border-bottom">Our Location</h1>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227825.4781133533!2d80.94616521677925!3d26.847168379271583!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39995761144d1493%3A0x9901bb1bd11fdb24!2sKMC%20Hospital!5e0!3m2!1sen!2sin!4v1641156401655!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>
<div class="row bg-dark">
<div class="col-sm-3">
<h3 class="text-white mt-2 text-center">Visited To</h3>
<p class="text-white"><i class=" fa fa-map-marker-alt"> </i>KMC Hospital
Bandha road, near purania flyover, Fazullaganj, Lucknow, Uttar Pradesh 226013
</p>
</div>
<div class="col-sm-3">
<h3 class="text-white mt-2 text-center">Quick Link</h3>
<ul class="">
<li  ><a href="index.php" class="nav-link">Home</a></li>
<li ><a href="appointment.php" class="nav-link">Appointment</a></li>
<li ><a href="patientres.html" class="nav-link">Patient Registration</a></li>
<li ><a href="aboutus.php" class="nav-link">About us</a></li>
<li ><a href="contactus.php" class="nav-link">Contect Page</a></li>
</ul>
</div>
<div class="col-sm-3">
<h3 class="text-white mt-2 text-center">Tools</h3>
<ul class="">
<li ><a href="#" class="nav-link">Event Calender</a></li>
<li ><a href="#" class="nav-link">Find a physician</a></li>
<li ><a href="#" class="nav-link">Faculty List</a></li>
<li><a href="#" class="nav-link">Online Bill Pay</a></li>
</ul>
</div>
<div class="col-sm-3">
<img src="img/logo2.png" class="mt-4" height="180px" width="180px" />
</form>

</div>
</div>

<div class="row aligh-items-center py-3 bg-primary">
            <div class="col-md-6  text-light">
                <div class="copy">
                    Copyright <script>document.write(new Date().getFullYear());</script>2022 © MMITIEN All Rights Reserved. 
                </div>
            </div>
            <div class="col-md-6  text-light text-right">
                <div class="d-flex justify-content-end">
                    <a href="https://www.facebook.com/saratechnologies/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/saratechnology" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-twitter"></i></a>
                    <a href="https://in.linkedin.com/company/sara-technologies-pvt-ltd" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-linkedin"></i></a>
                    <a href="https://www.instagram.com/websarasolutions/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-instagram"></i></a>
                    <a href="https://in.pinterest.com/saratechnologiespvtltd/" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-pinterest"></i></a>
                    <a href="https://www.youtube.com/channel/UCl748soyEhy9DLpib3nWE8w" target="_blank" class="btn btn-sm btn-light mr-1"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>






    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	</div>
  </body>
</html>