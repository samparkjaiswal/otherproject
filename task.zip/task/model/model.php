<?php
require "conect.php";
class modeldb extends dbconnected  
{
      public function insert_data()
    {
        //taking input from form
        if(isset($_POST['submit']))
        {
       $first_name=$_POST['fname'];
        $last_name=$_POST['lname'];
        $email=$_POST['email'];
        $user_name=$_POST['uname'];
        $password=$_POST['pass'];
        $class=$_POST['class'];
        $section=$_POST['section'];
        $father_name=$_POST['faname'];
        $mother_name=$_POST['maname'];
        $address=$_POST['address'];
        $phone=$_POST['phone'];
        $language=$_POST['language'];
        $lang=implode(',',$language);

        //insertion in basic details

        $sql_insert_bd="insert into basic(fname,lname,email,uname,pass,class,section) values('$first_name','$last_name','$email','$user_name','$password','$class','$section')";

        $result_bd=$this->conn_var->query($sql_insert_bd);
        if(!$result_bd)
        {
           // echo "Data inserted<br>";
           echo "Data Insertion Failed in Basic Detail!<br>";
           //die(mysqli_error($sql_insert_query_runner_bd));
           die($this->conn_var->error);
        }
        
       

        //fetching student id
        $fetch_id = mysqli_insert_id($this->conn_var);

        //insertion in personal details
       $sql_insert_pd="insert into personal(faname,maname,address,phone,std_id) values('$father_name','$mother_name','$address','$phone','$fetch_id')";

        $result_pd=$this->conn_var->query($sql_insert_pd);
        if(!$result_pd)
        {
           // echo "Data inserted<br>";
           echo "Data Insertion Failed in Personal Detail!<br>";
           //die(mysqli_error($sql_insert_query_runner_pd));
           die($this->conn_var->error);
            
        }
      
        

        //insertion in subject

        $sql_insert_sb="insert into subject(subject,std_id) values('$lang','$fetch_id')";

        $result_sb=$this->conn_var->query($sql_insert_sb);
        if(!$result_sb)
        {
            //echo "Data inserted<br>";
            //header('location: ../view/form.php');
             // print "not working";
            //die(mysqli_error($sql_insert_query_runner_sb));
            echo "Data Insertion Failed in Subject Detail!<br>";
           
            die($this->conn_var->error);

        }
        else
        {
           echo "Data inserted";
            header('location: ../view/form.php');

        }
        
    }
}

    //fetch record from database

    public function display_record()
    {
        $sql_select="SELECT b.id, b.fname, b.lname, b.email, b.uname, b.class, b.section, p.faname, p.maname, p.address, p.phone, s.subject FROM ((basic AS b INNER JOIN personal AS p ON b.id = p.std_id) INNER JOIN subject AS s ON b.id = s.std_id)";

        $result_sel=$this->conn_var->query($sql_select);
        if($result_sel->num_rows>0)
        {
            while($row=$result_sel->fetch_assoc())
            {
              $data[]=$row;
            }
            return $data;
        }
    }


}
$objmodel = new modeldb();

$objmodel->insert_data();

//$data=$objmodel->display_record();

//call the display_record() function here and include this file(model.php) OR call display_record() function display.php file and include file(model.php) also.
?>