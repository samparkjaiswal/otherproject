<html>

<head>
<title>Login Page</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<body>

<div class="container">

<div class="row">
<!-- border color ke liye(border-info)-->
<div class="col-md-6 mt-5 m-auto bg-white shadow font-monospace border border-info">

<p class="text-warning text-center  fw-bold my-3" style="font-size:25">User Login</p>

<form action="codes/userlogin.php" method="post" autocomplete="off">

<div class="mb-3">

<label for="">UserName:</label>
<input type="text" placeholder="Enter User Name" name="user" required class="form-control"/>

</div>




<div class="mb-3">

<label for="">UserPassword:</label>
<input type="password" placeholder="Enter User Password" name="pass" required class="form-control"/>

</div>
<!-- button width(w-100) -->
<a href='userchangepass1.php'>Change Password</a>

<div class="mb-3">
<button class=" w-100 bg-danger text-white" style="font-size:22px">LOGIN</button>
</div>


<div class="mb-3">
<button class=" w-100 bg-warning text-white" name="submit" style="font-size:22px"><a href="uregistration.php" class="text-decoration-none text-white">NEW REGISTERATION HERE</a></button>
</div>

</form>

</div>

</div>

</div>

</body>

</html>