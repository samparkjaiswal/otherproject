<html>

<head>
<title>Registration Page</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<body>

<div class="container">

<div class="row">
<!-- border color ke liye(border-info)-->
<div class="col-md-6 mt-5 m-auto bg-white shadow font-monospace border border-info">

<p class="text-warning text-center  fw-bold my-3" style="font-size:25">User Register</p>

<form action="codes/uregister.php" method="post" autocomplete="off">

<div class="mb-3">

<label for="">UserName:</label>
<input type="text" placeholder="Enter User Name" name="user" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">UserEmail:</label>
<input type="email" placeholder="Enter User Email" name="email" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">Mobile:</label>
<input type="number" placeholder="Enter User Number" name="mobile" required class="form-control"/>

</div>

<div class="mb-3">

<label for="">UserPassword:</label>
<input type="password" placeholder="Enter User Password" name="pass" required class="form-control"/>

</div>

<div class="mb-3">

<label for="">City:</label>
<input type="text" placeholder="Enter City" name="city" required class="form-control"/>

</div>

<div class="mb-3">

<label for="">Gender:</label>
Male<input type="radio"  name="gender" value="male" required/>
Female<input type="radio"  name="gender" value="female" required/>

</div>

<!-- button width(w-100) -->
<div class="mb-3">
<button class=" w-100 bg-warning text-white" name="submit" style="font-size:22px">REGISTER</button>
</div>

<div class="mb-3">
<button class=" w-100 bg-danger text-white" style="font-size:22px"><a href="ulogin.php" class="text-decoration-none text-white">ALREADY ACCOUNT</a></button>
</div>

</form>

</div>

</div>

</div>

</body>

</html>