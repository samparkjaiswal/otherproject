<?php

include 'connection.php';
$id=$_GET['id'];
$sel="select * from user where id='$id'";
$query=mysqli_query($con,$sel);
while($data=mysqli_fetch_assoc($query))
{
	$user=$data['user'];
	$email=$data['email'];
	$mobile=$data['mobile'];
	$city=$data['city'];
	$gender=$data['gender'];
	
}


?>


<?php

if(isset($_POST['update']))
{
	$user=$_POST['user'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$city=$_POST['city'];
	$gender=$_POST['gender'];
	$date=date('d/m/y');
	$update="update user set user='$user',email='$email',mobile='$mobile',city='$city',gender='$gender',dt='$date' where id='$id'";
	$qu=mysqli_query($con,$update);
	if($qu)
	{
		echo "<script>alert('update sucessfully');window.location.href='../admin/registration.php'</script>";
	}
	else
	{
		echo "<script>alert('update failed');window.location.href='../admin/registration.php'</script>";
	}
}

?>





<html>

<head>
<title>Update Page</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<body>

<div class="container">

<div class="row">
<!-- border color ke liye(border-info)-->
<div class="col-md-6 mt-5 m-auto bg-white shadow font-monospace border border-info">

<p class="text-warning text-center  fw-bold my-3" style="font-size:25">User Update</p>

<form action="" method="post" autocomplete="off">

<div class="mb-3">

<label for="">UserName:</label>
<input type="text" placeholder="Enter User Name" value="<?php echo "$user" ?>" name="user" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">UserEmail:</label>
<input type="email" placeholder="Enter User Email" value="<?php echo "$email" ?>" name="email" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">Mobile:</label>
<input type="number" placeholder="Enter User Number" value="<?php echo "$mobile" ?>" name="mobile" required class="form-control"/>

</div>

<!--<div class="mb-3">

<label for="">UserPassword:</label>
<input type="password" placeholder="Enter User Password" name="pass" value="" required class="form-control"/>

</div>-->

<div class="mb-3">

<label for="">City:</label>
<input type="text" placeholder="Enter City" name="city"  value="<?php echo "$city" ?>" required class="form-control"/>

</div>

<div class="mb-3">

<label for="">Gender:</label>
Male<input type="radio"  name="gender" value="male" required

<?php

if($gender=="male")
{
	echo "checked";
}

?>

/>
Female<input type="radio"  name="gender" value="female" required

<?php

if($gender=="female")
{
	echo "checked";
}


?>

/>

</div>

<!-- button width(w-100) -->
<div class="mb-3">
<button class=" w-100 bg-warning text-white" name="update" style="font-size:22px">UPDATE</button>
</div>



</form>

</div>

</div>

</div>

</body>

</html>