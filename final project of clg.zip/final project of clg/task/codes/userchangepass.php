



<?php

include "connection.php";


$user=$_POST['email'];
$npass=$_POST['npass'];
$cpass=$_POST['cpass'];


$query="select email,pass from user where user='$user' or email='$user'";

$data=mysqli_query($con,$query);

$row=mysqli_fetch_array($data);
if($row>0)
{
	if($cpass==$npass)
	{
	   $update="update user set pass='$npass' where user='$user' or email='$user'";
	   mysqli_query($con,$update);
	
	   echo "<script>alert('Password Change Successfully');window.location.href='../ulogin.php'</script>";
	}
	else{
		echo "<script>alert('confrim password is wrong');window.location.href='../userchangepass1.php'</script>";
	}
}
else
{
	echo "<script>alert('Username/Email Id Is Wrong');window.location.href='../userchangepass1.php'</script>";
}

?>
