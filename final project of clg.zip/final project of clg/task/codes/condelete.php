

<?php

//Contact delete query

include 'connection.php';
$id=$_GET['id'];
$del=mysqli_query($con,"delete from contact where id='$id'");
if($del)
{
	header("location:../admin/contactmg.php");
}
else
{
	echo "<script>alert('Record Delete');window.location.href='../admin/contactmg.php'</script>";
}

?>