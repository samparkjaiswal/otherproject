<?php
include 'connection.php';
$id=$_GET['id'];
$del=mysqli_query($con,"delete from booking where id='$id'");
if($del)
{
	header("location:../admin/booking.php");
}
else
{
	echo "<script>alert('Record Not Delete');window.location.href='../admin/booking'</script>";
}

?>