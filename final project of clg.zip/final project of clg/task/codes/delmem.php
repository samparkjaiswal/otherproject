<?php
require "DBM.php";
$address=$_GET["d"];


$cmd="delete from member where address='$address'";

$db=new DBManager();
$x=$db->InsertUpdateOrDelete($cmd);
if($x==true)
{
	echo"<script>alert('Record Deleted');window.location.href='../admin/membermg.php'</script>";
}
else
{
	echo "<script>alert('Record not Deleted');window.location.href='../admin/membermg.php'</script>";
	
}

?>

