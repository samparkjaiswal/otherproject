<?php
require "connection.php";


if(isset($_POST['submit']))
{
$name=$_POST["name"];
$mob=$_POST["mob"];
$email=$_POST["email"];
$sub=$_POST["sub"];
$msg=$_POST["msg"];
$dt=date("d/m/Y");

//echo "name=$name , mobile = $mob , subject= $sub , massage = $msg and date = $dt";

//insert record into database
$query="insert into contact(name,mob,email,sub,msg,dt) values('$name','$mob','$email','$sub','$msg','$dt')";

$data=mysqli_query($con,$query);
if($data)
{
	echo"<script>alert('Thanks for contact');window.location.href='../map4.html'</script>";
}
else
{
	echo "<script>alert('your request not completed');window.location.href='../map4.html'</script>";
	
}

}

?>