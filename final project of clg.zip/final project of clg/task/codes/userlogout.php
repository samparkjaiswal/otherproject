<?php

session_start();

session_destroy();

//header("location:../ulogin.php");

echo "<script>alert('Logout');window.location.href='../pro.html'</script>";

?>