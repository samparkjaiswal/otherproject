<?php
include 'connection.php';
$id=$_GET['id'];
$sel="select * from member where id='$id'";
$query=mysqli_query($con,$sel);
while($data=mysqli_fetch_assoc($query))
{
	$name=$data['name'];
	$fname=$data['fname'];
	$gen=$data['gen'];
	$city=$data['city'];
	$mob=$data['mob'];
	$qualification=$data['qualification'];
	$address=$data['address'];
}
?>

<?php
if(isset($_POST['btn']))
{
	$name=$_POST['name'];
	$fname=$_POST['fname'];
	$gen=$_POST['gen'];
	$city=$_POST['city'];
	$mob=$_POST['mob'];
	$qualification=$_POST['qualification'];
	$address=$_POST['address'];
	$date=date('d/m/y');
	$update="update member set name='$name',fname='$fname',gen='$gen',city='$city',mob='$mob',qualification='$qualification',address='$address',dt='$date' where id='$id'";
	$qu=mysqli_query($con,$update);
	if($qu)
	{
		echo "<script>alert('update sucessfully');window.location.href='../admin/membermg.php'</script>";
	}
	else
	{
		echo "<script>alert('update failed');window.location.href='../admin/membermg.php'</script>";
	}
}

?>
<html>

<head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">



<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled and minified JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>

<link href="hover.css" rel="stylesheet"/>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>


<div class="container-fluid">
<div class="row" style="min-height:900px">
<div class="col-md-3 "></div>

<div class="col-md-6 bg-danger " style="border:2px solid black;min-height:750px;border-radius:10px;">

<form action="" method="post" autocomplete="off">

<h2 class="panel panel-primary" style="text-align:center"><b>Registration For Guider</b></h2><br><br><br>
Name<input type="text" class="form-control" name="name" value="<?php echo"$name"?>" placeholder="Enter Name"/><br>
Father Name<input type="text" class="form-control" name="fname" value="<?php echo "$fname"?>" placeholder="Enter Father Name"/><br>
Gender:    
&emsp;&emsp;
<input type="radio" name="gen" value="male"
<?php
if($gen=="male")
{
	echo "checked";
}
?>
/>Male&emsp;&emsp;
<input type="radio" name="gen" value="female"

<?php
if($gen=="female")
{
	echo "checked";
}
?>

/>Female<br><br>
City<input type="text" class="form-control" name="city" value="<?php echo "$city"?>" placeholder="City"/><br>
Mobile<input type="text" class="form-control" name="mob" value="<?php echo "$mob"?>"  placeholder="Enter Mobile Number"/><br>
Qualification
<select class="form-control" name="qualification" placeholder="Qualification">
<option hidden>Select Qualification</option>
<option value="HighSchool"
<?php
if($qualification=="HighSchool")
{
	echo "selected";
}

?>
>HighSchool</option>
<option value="Intermidiate"
<?php
if($qualification=="Intermidiate")
{
	echo "selected";
}

?>
>Intermidiate</option>
<option value="Diploma"
<?php
if($qualification=="Diploma")
{
	echo "selected";
}

?>
>Diploma</option>
<option value="B.Tech"
<?php
if($qualification=="B.Tech")
{
	echo "selected";
}

?>
>B.Tech</option>
</select><br>
Address<textarea class="form-control" name="address"  placeholder="Address"><?php echo "$address"?></textarea><br><br><br>

<center><button type="submit"  class="btn btn-success" name="btn">Update</button></center>
</form>

</div>
<div class="col-md-3"></div>


</div>
</div>
</body>
</html>