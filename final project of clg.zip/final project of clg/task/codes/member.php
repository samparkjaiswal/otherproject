<?php
include "connection.php";
$name=$_POST["name"];
$fname=$_POST["fname"];
$gen=$_POST["gen"];
$city=$_POST["city"];
$mob=$_POST["mob"];
$qualification=$_POST["qualification"];
$address=$_POST["address"];
$dt=date("d/m/Y");

//echo "name=$name , mobile = $mob , subject= $sub , massage = $msg and date = $dt";

//insert record into database
$cmd="insert into member(name,fname,gen,city,mob,qualification,address,dt) values('$name','$fname','$gen','$city','$mob','$qualification','$address','$dt')";

$data=mysqli_query($con,$cmd);

if($data)
{
	echo"<script>alert('Registration Succesfull');window.location.href='../become.html'</script>";
}
else
{
	echo "<script>alert('your request not completed');window.location.href='../become.html'</script>";
	
}

?>