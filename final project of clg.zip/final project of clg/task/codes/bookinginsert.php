<?php


include "connection.php";

$name=$_POST["name"];
$email=$_POST["email"];
$mobile=$_POST["mobile"];
$city=$_POST["city"];
$destination=$_POST["destination"];
$person=$_POST["person"];
$jdate=$_POST["jdate"];
$dt=date("y/m/d");

//echo "name=$name , mobile = $mob , subject= $sub , massage = $msg and date = $dt";

//insert record into database
$cmd="insert into booking(name,email,mobile,city,destination,person,jdate,dt) values('$name','$email','$mobile','$city','$destination','$person','$jdate','$dt')";

$data=mysqli_query($con,$cmd);

if($data)
{
	echo"<script>alert('Booking Succesfull');window.location.href='../bttv.php'</script>";
}
else
{
	echo "<script>alert('your request not completed');window.location.href='../bttv.php'</script>";
	
}


?>