<?php
$con=mysqli_connect("localhost","root","","tourism");

if($con)
{
	//echo "Connection Successfull";
}
else
{
	echo "echo Connection Failed";
}
?>
