<?php

include 'connection.php';
$id=$_GET['id'];
$sel="select * from contact where id='$id'";
$query=mysqli_query($con,$sel);
while($data=mysqli_fetch_assoc($query))
{
	$name=$data['name'];
	$mob=$data['mob'];
	$email=$data['email'];
	$sub=$data['sub'];
	$msg=$data['msg'];
	
}


?>


<?php

if(isset($_POST['submit']))
{
	$name=$_POST['name'];
	$mob=$_POST['mob'];
	$email=$_POST['email'];
	$sub=$_POST['sub'];
	$msg=$_POST['msg'];
	$date=date('d/m/y');
	$update="update contact set name='$name',mob='$mob',email='$email',sub='$sub',msg='$msg',dt='$date' where id='$id'";
	$qu=mysqli_query($con,$update);
	if($qu)
	{
		echo "<script>alert('update sucessfully');window.location.href='../admin/contactmg.php'</script>";
	}
	else
	{
		echo "<script>alert('update not sucessfully');window.location.href='../admin/contactmg.php'</script>";
	}
}
?>

<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
<div class="container-fluid">
<div class="col-md-3"></div>
<div class="col-md-6" style="min-height:420px;background-color:darkseagreen">
 
 <form action="" method="post" autocomplete="off">
 
<h3 style="text-align:center;font-size:60px;color:maroon"><b>Contact Details....</b></h3><hr style="border:1px solid black">

<input type="text" placeholder="Enter Name" name="name" value="<?php echo"$name"?>" maxlength="50" style="width:300px;height:30px;font-size:20px"  required />&emsp;
<input type="text" placeholder="Mobile Number" name="mob" value="<?php echo"$mob"?>" maxlength="12"  style="width:300px;height:30px;font-size:20px"  required /><br><br>
<input type="text" placeholder="Enter Email Id" name="email" value="<?php echo"$email"?>" style="width:300px;height:30px;font-size:20px"  required /><br><br>
<input type="text" placeholder="Subject" name="sub" value="<?php echo"$sub"?>" maxlength="100" style="width:350px;height:30px;font-size:20px"  required /><br><br>
<textarea  name="msg" placeholder="Massage" style="width:350px;height:70px;font-size:20px" required ><?php echo"$msg"?></textarea><br><br>
<center><button type="submit" name='submit' class="btn btn-success" style="color:white;text-decoration:none">Update</button></center>
 
 </form>
 <div class="col-md-3"></div>
 </div>
 </div>
 </body>
 </html>