<?php

include 'connection.php';
$id=$_GET['id'];
$sel="select * from booking where id='$id'";
$query=mysqli_query($con,$sel);
while($data=mysqli_fetch_assoc($query))
{
	$name=$data['name'];
	$email=$data['email'];
	$mobile=$data['mobile'];
	$city=$data['city'];
	$destination=$data['destination'];
	$person=$data['person'];
	$jdate=$data['jdate'];
	
	
}




?>




<?php

if(isset($_POST['update']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$city=$_POST['city'];
	$destination=$_POST['destination'];
	$person=$_POST['person'];
	$jdate=$_POST['jdate'];
	$date=date('y/m/d');
	$update="update booking set name='$name',email='$email',mobile='$mobile',city='$city',destination='$destination',person='$person',jdate='$jdate',dt='$date' where id='$id'";
	$qu=mysqli_query($con,$update);
	if($qu)
	{
		echo "<script>alert('update sucessfully');window.location.href='../admin/booking.php'</script>";
	}
	else
	{
		echo "<script>alert('update failed');window.location.href='../admin/booking.php'</script>";
	}
}

?>









<html>

<head>
<title>Booking Page</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<style>
   
#txt{
	border:1px solid brown;
	border-radius:5px;
	height:5%;
	
}

.col-md-6 select{
	border:1px solid brown;
	border-radius:5px;
	box-shadow:1px 1px 2px 1px grey;
	heigth:5%;
	
}
</style>

</head>

<body>

<div class="container-fluid">

<div class="row" style="background:url('red.jpg');background-size:100%100%">
<!-- border color ke liye(border-info)-->
<div class="col-md-6 mt-5 m-auto bg-white shadow font-monospace border border-info rounded  opacity-75 "  style="">



<p class="text-warning text-center   fw-bold my-3" style="font-size:25">Booking Here</p><br>
<p class="text-danger    fw-bold " style="font-size:16">** Please Visit With Your ID(aadhar,pan,dl) **</p>

<form action="" method="post"    autocomplete="off">

<div class="mb-3">

<label for="">Name:</label>
<input type="text" id="txt" placeholder="Enter Name" value="<?php echo "$name" ?>" name="name" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">Email:</label>
<input type="email" id="txt" placeholder="Enter Email" value="<?php echo "$email" ?>" name="email" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">Mobile:</label>
<input type="number" id="txt" placeholder="Enter Number" value="<?php echo "$mobile"?>" name="mobile" required class="form-control"/>

</div>



<div class="mb-3">

<label for="">City:</label>
<input type="text" id="txt" placeholder="Enter City" value="<?php echo "$city" ?>" name="city" required class="form-control"/>

</div>

<div class="mb-3">

<label for="">Destination:</label>
<select class="form-control" name="destination" required>

<option hidden>Where You Want To Go</option>
<option value="Agara"

<?php

if($destination=="Agara")
{
	echo "selected";
}

?>


>Agara</option>
<option value="Goa"

<?php

if($destination=="Goa")
{
	echo "selected";
}


?>

>Goa</option>
<option value="Ladhakh"

<?php

if($destination=="Ladhakh")
{
	echo "selected";
}



?>

>Ladhakh</option>
<option value="Lucknow"

<?php

if($destination=="Lucknow")
{
	echo "selected";
}


?>

>Lucknow</option>
<option value="Varanasi"

<?php

if($destination=="Varanasi")
{
	echo "selected";
}


?>

>Varanasi</option>

</select>
<!--<input type="text" placeholder="Where You Want To Go" name="destination" required class="form-control"/>-->

</div>

<div class="mb-3">

<label for="">No Of Person:</label>
<input type="text" id="txt" placeholder="No Of Person" value="<?php echo "$person" ?>" name="person" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">Journey Date:</label>
<input type="date"id="txt" placeholder="" value="<?php echo "$jdate" ?>" name="jdate" required class="form-control"/>

</div>

<!-- button width(w-100) -->
<div class="mb-3">
<button class=" w-100 bg-primary fw-bold text-white" name="update" style="font-size:22px">Update Booking</button>
</div>



</form>

</div>

</div>

</div>


</body>

</html>
