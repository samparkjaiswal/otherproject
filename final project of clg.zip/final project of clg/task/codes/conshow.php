<html>
<body>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<table class="table table-responsive" style="text-align:center" border="2px">
<tr>
<td>Id</td>
<td>Name</td>
<td>Mobile</td>
<td>Email</td>
<td>Subject</td>
<td>Massage</td>
<td>Date</td>
<td colspan="2">OPRATION</td>
</tr>
<?php
include 'connection.php';
$sel="select * from  contact";
$query=mysqli_query($con,$sel);
while($data=mysqli_fetch_assoc($query))
{
	echo "<tr>
	<td>".$data['id']."</td>
	<td>".$data['name']."</td>
	<td>".$data['mob']."</td>
	<td>".$data['email']."</td>
	<td>".$data['sub']."</td>
	<td>".$data['msg']."</td>
	<td>".$data['dt']."</td>
	<td><a href='condelete.php?id=$data[id]'><span class='fa fa-trash' style='color:red'></span></a></td>
	<td><a href='conupdate.php?id=$data[id]'><span class='fa fa-edit' style='color:blue'></span></a></td>
	
	
	</tr>";
}

?>
</table>
</body>
</html>
