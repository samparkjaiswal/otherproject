<?php

include "connection.php";

session_start();


$user=$_POST['user'];
$pass=$_POST['pass'];

$query="select user,pass from user where (user='$user' or email='$user') and pass='$pass'";

$data=mysqli_query($con,$query);

$row=mysqli_num_rows($data);



if($row)
{
	$_SESSION['admin']=$user;
	echo "<script>alert('Login Success');window.location.href='../bttv.php'</script>";
}
else
{
	echo "<script>alert('Wrong Username/Email/Password');window.location.href='../ulogin.php'</script>";
}

?>