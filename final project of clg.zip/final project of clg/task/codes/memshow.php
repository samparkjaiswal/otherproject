

<html>

<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

<table border="2px solid black" style="text-align:center">

<tr>

<td>Id</td>
<td>Name</td>
<td>FatherName</td>
<td>Gender</td>
<td>City</td>
<td>Mobile</td>
<td>Qualification</td>
<td>Address</td>
<td>Date</td>
<td colspan="2">Operation</td>


</tr>

<?php

include "connection.php";

$query=mysqli_query($con,"select * from member");

while($row=mysqli_fetch_assoc($query))
{
	echo "
	
	<tr>
	<td>".$row['id']."</td>
	<td>".$row['name']."</td>
	<td>".$row['fname']."</td>
	<td>".$row['gen']."</td>
	<td>".$row['city']."</td>
	<td>".$row['mob']."</td>
	<td>".$row['qualification']."</td>
	<td>".$row['address']."</td>
	<td>".$row['dt']."</td>
	<td><a href='memupdate.php?id=$row[id]'><span class='fa fa-edit' style='color:blue'></span></a></td>
	<td><a href='memdelete.php?id=$row[id]'><span class='fa fa-trash' style='color:red'></span></a></td>
	
	
	</tr>
	
	";
}


?>

</table>

</body>

</html>