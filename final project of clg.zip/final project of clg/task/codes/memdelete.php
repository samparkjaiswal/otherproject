<?php
include 'connection.php';
$id=$_GET['id'];
$del=mysqli_query($con,"delete from member where id='$id'");
if($del)
{
	header("location:../admin/membermg.php");
}
else
{
	echo "<script>alert('Record Delete');window.location.href='../admin/membermg.php'</script>";
}

?>