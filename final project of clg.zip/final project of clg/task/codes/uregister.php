<?php

include "connection.php";

$user=$_POST["user"];
$email=$_POST["email"];
$mobile=$_POST["mobile"];
$pass=$_POST["pass"];
$city=$_POST["city"];
$gender=$_POST["gender"];
$dt=date("d/m/Y");

//echo "name=$name , mobile = $mob , subject= $sub , massage = $msg and date = $dt";

//insert record into database
$cmd="insert into user(user,email,mobile,pass,city,gender,dt) values('$user','$email','$mobile','$pass','$city','$gender','$dt')";

$data=mysqli_query($con,$cmd);

if($data)
{
	echo"<script>alert('Registration Succesfull');window.location.href='../ulogin.php'</script>";
}
else
{
	echo "<script>alert('your request not completed');window.location.href='../ulogin.php'</script>";
	
}



?>