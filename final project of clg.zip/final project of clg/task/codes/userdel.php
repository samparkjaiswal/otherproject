<?php
include 'connection.php';
$id=$_GET['id'];
$del=mysqli_query($con,"delete from user where id='$id'");
if($del)
{
	header("location:../admin/registration.php");
}
else
{
	echo "<script>alert('Record Delete');window.location.href='../admin/registration.php'</script>";
}

?>