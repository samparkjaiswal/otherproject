
<html>

<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

<table border="2px solid black" style="text-align:center">

<tr>

<td>Id</td>
<td>UserName</td>
<td>Email Id</td>
<td>Mobile</td>
<td>City</td>
<td>Gender</td>
<td>Date</td>
<td colspan="2">Operation</td>


</tr>	


<?php

include "connection.php";

$query=mysqli_query($con,"select * from user");

while($row=mysqli_fetch_assoc($query))
{
	echo "
	
	<tr>
	<td>".$row['id']."</td>
	<td>".$row['user']."</td>
	<td>".$row['email']."</td>
	<td>".$row['mobile']."</td>
	<td>".$row['city']."</td>
	<td>".$row['gender']."</td>
	<td>".$row['dt']."</td>
	<td><a href='userupdate.php?id=$row[id]'><span class='fa fa-edit' style='color:blue'></span></a></td>
	<td><a href='userdel.php?id=$row[id]'><span class='fa fa-trash' style='color:red'></span></a></td>
	
	
	</tr>
	
	";
}



?>
</table>

</body>

</html>