<html>

<head>
<title>Booking Page</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<style>
   
#txt{
	border:1px solid brown;
	border-radius:5px;
	height:5%;
	
}

.col-md-6 select{
	border:1px solid brown;
	border-radius:5px;
	box-shadow:1px 1px 2px 1px grey;
	heigth:5%;
	
}
</style>

</head>

<body>

<div class="container-fluid">

<div class="row" style="background:url('red.jpg');background-size:100%100%">
<!-- border color ke liye(border-info)-->
<div class="col-md-6 mt-5 m-auto bg-white shadow font-monospace border border-info rounded  opacity-75 "  style="">



<p class="text-warning text-center   fw-bold my-3" style="font-size:25">Booking Here</p><br>
<p class="text-danger    fw-bold " style="font-size:16">** Please Visit With Your ID(aadhar,pan,dl) **</p>

<form action="codes/bookinginsert.php" method="post"    autocomplete="off">

<div class="mb-3">

<label for="">Name:</label>
<input type="text" id="txt" placeholder="Enter Name" name="name" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">Email:</label>
<input type="email" id="txt" placeholder="Enter Email" name="email" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">Mobile:</label>
<input type="number" id="txt" placeholder="Enter Number" name="mobile" required class="form-control"/>

</div>



<div class="mb-3">

<label for="">City:</label>
<input type="text" id="txt" placeholder="Enter City" name="city" required class="form-control"/>

</div>

<div class="mb-3">

<label for="">Destination:</label>
<select class="form-control" name="destination" required>

<option hidden>Where You Want To Go</option>
<option>Agara</option>
<option>Goa</option>
<option>Ladhakh</option>
<option>Lucknow</option>
<option>Varanasi</option>

</select>
<!--<input type="text" placeholder="Where You Want To Go" name="destination" required class="form-control"/>-->

</div>

<div class="mb-3">

<label for="">No Of Person:</label>
<input type="text" id="txt" placeholder="No Of Person" name="person" required class="form-control"/>

</div>


<div class="mb-3">

<label for="">Journey Date:</label>
<input type="date"id="txt" placeholder="" name="jdate" required class="form-control"/>

</div>

<!-- button width(w-100) -->
<div class="mb-3">
<button class=" w-100 bg-primary fw-bold text-white" name="submit" style="font-size:22px">Book Now</button>
</div>



</form>

</div>

</div>

</div>


</body>

</html>
