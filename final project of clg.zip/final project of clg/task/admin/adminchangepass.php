



<?php

include "../codes/connection.php";


$opass=$_POST['opass'];
$npass=$_POST['npass'];
$cpass=$_POST['cpass'];


$query="select pass from admin where pass='$opass'";

$data=mysqli_query($con,$query);

$row=mysqli_fetch_array($data);
if($row)
{
	if($cpass==$npass)
	{
	   $update="update admin set pass='$npass'";
	   mysqli_query($con,$update);
	
	   echo "<script>alert('Password Change Successfully');window.location.href='changepass.php'</script>";
	}
	else{
		echo "<script>alert('confrim password is wrong');window.location.href='changepass.php'</script>";
	}
}
else
{
	echo "<script>alert('Old Password Is Wrong');window.location.href='changepass.php'</script>";
}

?>
