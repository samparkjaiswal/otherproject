<?php
session_start();
$user=$_POST["user"];
$pass=$_POST["pass"];

$con=mysqli_connect("localhost","root","","tourism");
if($con)
{
	$cmd="select * from admin where user='$user' and pass='$pass'";
	$x=mysqli_query($con,$cmd);
	if(mysqli_num_rows($x)>0)
	{
		$_SESSION['admin']=$user;
		echo "<script>alert('Welcome to Admin Zone');window.location.href='dash.php'</script>";
	}
	else
	{
		echo "<script>alert('Invalid userid or Password');window.location.href='../login2.html'</script>";
	}
}
else
{
	mysqli_error($con);
}
?>

