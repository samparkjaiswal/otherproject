<html>
<head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled and minified JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>

<link href="hover.css" rel="stylesheet"/>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>
<body>

<?php

session_start();
if(!$_SESSION['admin'])
{
	header('location:ulogin.php');
}


?>

<div class="container-fluid">




<div class="row" style="background-color:blue">
<img src="logo.png" style="height:400px;width:100%"/>
</div>

<div class="row">
<div class="col-md-12" style="min-height:100px;background-color:antiquewhite;">
<marquee behavior="alternate" direction="right" scrollamount="10ms"><h2 style="font-size:60px;color:forestgreen"><b>Visited India On Vacation's</b></h2></marquee>
</div>
</div>

<div class="row">

<nav class="navbar navbar-default" style="background:yellow">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
	 
	  
	  <li><a href="" style="font-size:20px;"><i style="font-size:20px;color:red" class="fa fa-user   "> <span class="" style="color:red">Hello, <?php echo $_SESSION['admin'];?></span></i></a></li>
	 
        <li><a href="pro.html" style="font-size:20px;color:white"><span style="font-size:20px;color:blue" class="fa fa-home"> Home</span></a></li>
     <!--   <li><a href="#" style="font-size:20px;color:white"><span style="font-size:20px;color:white" class="fa fa-map-marker"> Destination</span></a></li>  -->
       <!-- <li><a href="bttv.html" style="font-size:20px;color:white"><span style="font-size:20px;color:blue" class="fa fa-clock-o"> Best Time To Visit</span></a></li>-->
        <li><a href="booking.php" style="font-size:20px;color:white"><span style="font-size:20px;color:blue" class="fa fa-building"> Booking Here</span></a></li>
       <!-- <li><a href="map4.html" style="font-size:20px;color:white"><span style="font-size:20px;color:white" class="fa fa-phone"> Contact Us</span></a></li>
        <li><a href="about.html" style="font-size:20px;color:white"><span style="font-size:20px;color:white" class="fa fa-address-card"> About Us</span></a></li>
		<li><a href="become.html" style="font-size:20px;color:white"><span style="font-size:20px;color:white" class="fa fa-user"> Become A Member</span></a></li>-->
       
        <li class="dropdown">
          <a href="#" class="dropdown-toggle fa fa-map-marker" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="color:blue;font-size:20px;">   Destination <span class="caret" style="font-size:20px;color:blue"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Ladakh</a></li>
            <li><a href="goa.html">Goa</a></li>
			
			
             
            
          </ul>
        </li>
		
		
				
      </ul>
	  
	  
	  
	  
	  
	 
	  
	  

	  

     <ul class="nav navbar-nav navbar-right">
	   <li class="dropdown">
          <a href="#" class="dropdown-toggle fa fa-sign-out" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="font-size:20px;color:blue"> Logout User<span class="caret"></span></a>
          <ul class="dropdown-menu">
   <!--       <li><a href="login2.html">Registration</a></li> -->
	<li><a href="codes/userlogout.php">Logout</a></li>
            
		
           
    
		</ul>
        </li>
      </ul>
	  
	  
	  
	<!--   <ul class="nav navbar-nav navbar-right">
	   <li class="dropdown">
          <a href="#" class="dropdown-toggle fa fa-sign-in" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="font-size:20px;color:white">  Admin LogIn<span class="caret"></span></a>
          <ul class="dropdown-menu">-->
      <!--      <li><a href="#" data-toggle="modal" data-target="#myModal">Registration</a></li>   -->
   

   <!--        <li><a href="login2.html">LogIn</a></li>
            
           
           
     
		</ul>
        </li>
      </ul>-->
	  
	  
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>



</div>


<!--Slider-->



<div class="row" style="margin-top:-1.5%">
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="img2/best.jpeg" style="height:430px;width:100%">
      <div class="carousel-caption">
        
      </div>
    </div>
    <div class="item">
      <img src="img2/ladh.jpeg" style="height:430px;width:100%">
      <div class="carousel-caption">
        
      </div>
    </div>
	<div class="item">
      <img src="img2/uttr.jpeg" style="height:430px;width:100%">
      <div class="carousel-caption">
        
      </div>
    </div>
	<div class="item">
      <img src="img2/goa.jpeg" style="height:430px;width:100%">
      <div class="carousel-caption">
        
      </div>
    </div>
    
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>



</div>






















<div class="row">



<div class="col-md-5" style="min-height:500px;">

<img src="img2/best.jpeg" style="height:300px;width:100%;margin-top:100px"/>

</div>

<div class="col-md-7" style="min-height:500px">
<h2 style="text-align:center;font-size:35px"><b>Best Time To Visit Taj Mahal</b></h2><hr>
<p style="font-size:20px;"><b>Taj Mahal at Sunrise</b></p>
<p style="text-align:justify">
The first rays of the sun illuminating the icon among the ‘Seven Wonders of the World’ is a moment of delight. The soft golden color is heartwarming. At this hour you can get lost in the magical feel of everlasting love. Also, free of crowds you can enjoy the beauty at your own leisure.</p><br>

<p style="font-size:20px;"><b>Taj Mahal at Sunset</b></p>
<p style="text-align:justify">As the sun bids adieu, people flock to the Taj to forget all that is wrong in the world and be in a moment of utter calmness. Sunset makes the pearl while shade softly turn a fiery yellow and then a soft orange and then a timeless beauty.</p><br>

<p style="font-size:20px;"><b>Taj Mahal under Full Moon Night</b></p>
<p style="text-align:justify">If you believe in fairytales or eternal love then you must visit the Taj Mahal on a full moon night. The view of the moonlit Taj Mahal is absolutely beyond words. After a glimpse of the shining moon over the wonder of the world, few things will be able to enthrall you.<br><br>
Tickets for night viewing the Taj Mahal is allowed on the full moon night, two days before it and two days after it. Get advance bookings for the tickets for entry. Explore customized Taj Mahal Tour Packages.</p>



</div>



</div>










<div class="row">



<div class="col-md-5" style="min-height:550px;">

<img src="img3/goa2.jpeg" style="height:300px;width:100%;margin-top:100px"/>

</div>

<div class="col-md-7" style="min-height:550px">
<h2 style="text-align:center;font-size:35px"><b>Best Time To Visit Goa</b></h2><hr>
<p style="font-size:20px;"><b>Summer Season: (March-May)</b></p>
<p style="text-align:justify">it can be considered as a good Goa holiday season to avail lucrative discounts and witness less-crowd. Also, the beaches remain tepid and the cerulean waters of the Arabian Sea lure visitors for taking a dip. So, if the sun shining brightly doesn’t bother you much, you can plan a trip in this season.</p><br>

<p style="font-size:20px;"><b>Mansoon Season: (June-September)</b></p>
<p style="text-align:justify">The showers bring a blissful respite after the scorching heat. Waterfalls start flowing with full might, nature gets a new life and beaches appear mesmerizing. Thus, nature lovers can consider it the best time to go to Goa. Witnessing the Dudhsagar waterfalls, going for trekking, rejuvenating with Ayurveda therapies will make your trip memorable.</p><br>

<p style="font-size:20px;"><b>Winter: (November-February</b></p>
<p style="text-align:justify">The best of them all, winter season in Goa starts in November and continues till February. It is that time of the year when Goa becomes a dream destination for many. From eminent personalities to popular music bands mark their presence in the state. Christmas and New Year merrymaking is at full swing and the state offers a bundle of matchless experiences to all the visitors. Basking in the sunshine completes the picture of Goa as a land of sun, sand and the sea.</p>



</div>



</div>














<div class="row">



<div class="col-md-5" style="min-height:550px;">

<img src="img3/ladh2.jpeg" style="height:300px;width:100%;margin-top:100px"/>

</div>

<div class="col-md-7" style="min-height:550px">
<h2 style="text-align:center;font-size:35px"><b>Best Time To Visit Ladakh</b></h2><hr>
<p style="font-size:20px;"><b>Best time for a bike trip in Ladakh</b></p>
<p style="text-align:justify">The joy of touching the landscapes of Ladakh, setting new challenges is what keeps adventure lovers coming back here. No matter what season has taken over this loved destination, thrill seekers are always ready to pick their leather jackets and zoom straightaway. However, the best time to visit Ladakh for bike trips is between May and September. This is because all the routes and passes open up around this time of the year.</p><br>

<p style="font-size:20px;"><b>Best time for trekking and camping in Ladakh</b></p>
<p style="text-align:justify">Without a doubt, summer is the best time for trekking and camping in Ladakh. Not only does the snow starts to clear off, but the weather becomes enjoyable. You can spend endless hours out exploring and end the day by enjoying a bonfire and just feeling the good vibes of Ladakh.

Moreover, the temperature between the months of May and October 25°C to 10°C. Some of the famous treks perfect for this season are Lamayuru to Chilling trek, Spituk to Matho trek, Markha Valley trek, Padum to Darcha trek to name a few.</p><br>

<p style="font-size:20px;"><b>What is the best time to visit Ladakh?</b></p>
<p style="text-align:justify">Roll out the carpet for summer, as it is the best time to visit Ladakh. As soon as June slips in, this cold desert leaves behind the cold breeze and becomes a paradise for travelers. One can actually sense comfort in the climate, as it's not too hot and not too cold. As months, go by the snow starts to melt making it perfect for the tourist season to commence.

Further, the famous Hemis Dance Festival celebrated at Hemis Monastery is another crowd puller. The 2-day fiesta honors the birth anniversary of Guru Padmasambhava, with handicrafts put on display, Lamas dancing to the traditional music and cymbals clashing along.</p>



</div>



</div>













<div class="row">



<div class="col-md-5" style="min-height:550px;">

<img src="img3/uttr2.jpeg" style="height:300px;width:100%;margin-top:100px"/>

</div>

<div class="col-md-7" style="min-height:550px">
<h2 style="text-align:center;font-size:35px"><b>Best Time To Visit Uttarakhand</b></h2><hr>
<p style="font-size:20px;"><b>Summer in Uttarakhand</b></p>
<p style="text-align:justify">From Mid-April, Uttarakhand experiences the delight of the summer season. Snow and cold winters have bid their farewells, and spring is in the air. The hill stations, Mussoorie, Nainital, and Ranikhet among others are seen crowded. The heat is unknown in the hills and the weather is certainly salubrious. In fact the land, rivers and the mountains are seen rejoicing. Wildlife expeditions are also on the rise. The thirsty royal Bengal Tigers in Jim Corbett National Park are quite a view to look at.</p><br>

<p style="font-size:20px;"><b>Monsoon in Uttarakhand</b></p>
<p style="text-align:justify">Arriving by mid-June and lasting till September, monsoon in Uttarakhand is an impressive spectacle of nature. The season is favorable for traveling as long as you do not mind getting wet. The hill towns appear all the more charming an also hotel prices are low and there are hardly any crowd to disturb your solitude.</p><br>

<p style="font-size:20px;"><b>Winter in Uttarakhand</b></p>
<p style="text-align:justify">With November the faint whispers of winter arrive in Uttarakhand, while it arrives earlier or never leaves in the higher lap of the Himalayas. The chilly winters are here to stay till February and March. Snowfall transforms the land in a fascinating beauty. Auli with its picture-perfect slopes gets all ready to host skiing and also is known as the ‘Ski Capital of India’. The other hill town of Nainital, Mussoorie, etc. </p>



</div>



</div>










<div class="row" style="min-height:300px;background-color:darkslateblue">
 
<div class="col-md-1"></div>

<div class="col-md-2">
<h4 style="color:white;padding-top:30px">COMPANY</h4><br>
<p style="color:white;font-size:15px">Destination<br>India Tour<br>About Us<br>Terms And Conditions</p>
</div>

<div class="col-md-6">

<h4 style="color:white;padding-top:30px">WHY INDIA TOURIST</h4><br>
<p style="color:white;font-size:15px;text-align:justify">India Tourist is a trusted and one of the most reliable names in the world of tours and travels. With years of fruitful experiences we have managed to put up a team of talented individuals who are ready to catar to all sorts of your travel related needs and packages. We make you fail in love with the place you are visiting.</p>

</div>

<div class="col-md-2">

<h4 style="color:white;padding-top:30px;">GET IN TOUCH</h4><br>
<p style="color:white;font-size:15px" class="fa fa-clock-o"><b>913 654 4185</b><b class="fa fa-envelope-square">travel@indiatourist.in</b></p><br><br>
<button class="fa fa-facebook" style="font-size:25px;background-color:gold;width:45px;height:35px;border-radius:4px"></button>
<button class="fa fa-twitter" style="font-size:25px;background-color:gold;width:45px;height:35px;border-radius:4px"></button>
<button class="fa fa-instagram" style="font-size:25px;background-color:gold;width:45px;height:35px;border-radius:4px"></button>
<button class="fa fa-google-plus" style="font-size:25px;background-color:gold;width:45px;height:35px;border-radius:4px"></button>
</div>

<div class="col-md-1"></div>


</div>




<div class="row">

<div class="col-md-1" style="min-height:200px;background-color:teal"></div>



<div class="col-md-5" style="min-height:200px;background-color:teal">
<img src="logo.png" style="height:150px;width:100%;margin-top:30px"/>


</div>








<div class="col-md-1" style="min-height:200px;background-color:teal">
<img src="footer.jpg" style="margin-top:10px" /></div>

<div class="col-md-4" style="min-height:200px;background-color:teal">
 <h2 style="font-size:30px;padding-left:10px;color:" ><b>Office Address</h2></p><hr style="border:1px solid black">
 <h4 style="font-size:18px;color:maroon;padding-left:20px"><b>Indian Tourist Pvt.Ltd.</b></h4>
 <p style="padding-left:20px;font-size:14px">70, L.G.F, World Trade Centre<br>Barakhamba Lane, New Delhi-110001 (INDIA)<br>Tel: +91 11 4242 3100</p>

</div>



<div class="col-md-1" style="min-height:200px;background-color:teal"></div>

</div>




<div class="row">
<div class="col-md-12" style="min-height:50px;background:cornflowerblue;text-align:center;font-size:20px;color:white"><h2>
Copyright Mecatredz Technology | Developed & Designed By Sampark Jaiswal</h2></div>
</div>




</div>

</body>
</html>

