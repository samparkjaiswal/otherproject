

<html>

<head>

<title>Change Password</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>


<body>


<div class="row" style="min-height:50px;">
	
	<div class="col-md-3"></div>
	
	<div class="col-md-6">
	<h1 style="text-align:center"><b>Change Password</b></h1>
	</div>
	
	<div class="col-md-3"></div>
	
	</div>
	
	<div class="row">
	
	<div class="col-md-3"></div>
	
	
	
		<div class="col-md-6" style="border:2px solid black;min-height:400px;border-radius:10px">
		
		
		<form action="codes/userchangepass.php" method="post" autocomplete="off">
		    
		    
		<!--	<label style="margin-top:50px">Old Password</label>
		    <div class="form-group pass_show"> 
                <input type="password" value="" name="opass" class="form-control" placeholder="Current Password"> 
            </div>-->
			
			<label style="margin-top:50px">Email Id/Username</label>
            <div class="form-group pass_show"> 
                <input type="text" value="" name="email" class="form-control" placeholder="Email Id or Username"> 
            </div> 
			
		       <label>New Password</label>
            <div class="form-group pass_show"> 
                <input type="password" value="" name="npass" class="form-control" placeholder="New Password"> 
            </div> 
		    <label>Confirm Password</label>
           <div class="form-group pass_show"> 
                <input type="password" value="" name="cpass" class="form-control" placeholder="Confirm Password"> 
            </div> 
			
			
		<center>	<button  type="submit" class="btn btn-success" name="submit"  style="margin-top:20px" >Change Password</button> </center>
           </form>

		   
		</div> 
		<div class="col-md-3"></div>
	
	</div>
	
	
	</body>
	
	</html>